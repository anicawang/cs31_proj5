#include <iostream>
#include <cstring>
#include <cctype>
#include <cassert>
using namespace std;

//define max size of word
const int MAX_WORD_LENGTH = 20;

//method to shift every element in array one spot forward to delete
void shift(char win[][MAX_WORD_LENGTH+1], char wout[][MAX_WORD_LENGTH+1], int& nRules, int &index)
{
    //loop through array
    for(int i = index; i < nRules - 1; i++)
    {
        //for each win and wout, copy the next element into the position of the previous one
        strcpy(win[i], win[i + 1]);
        strcpy(wout[i], wout[i + 1]);
    }
    //decrement index and nRules to check the elements copied into the position of replaced elements
    index--;
    nRules--;
}

//method to put a collection of purported match rules into clean form
int cleanupRules(char wordin[][MAX_WORD_LENGTH+1],
                 char wordout[][MAX_WORD_LENGTH+1],
                 int nRules)
{
    //treat negative nRules parameter as if it were 0
    if(nRules <= 0)
    {
        return 0;
    }
    
    //iterate through elements in array
    for(int i = 0; i < nRules; i++)
    {
        //iterate through characters in wordin
        for(int j = 0; j < strlen(wordin[i]); j++)
        {
            //convert all letters in wordin array to lower case
            wordin[i][j] = tolower(wordin[i][j]);
        }
        //iterate through characters in wordout
        for(int k = 0; k < strlen(wordout[i]); k++)
        {
            //convert all letters in wordout array to lower case
            wordout[i][k] = tolower(wordout[i][k]);
        }
    }
    
    //track modifications of nRules
    int rules = nRules;
    
    //remove match rule if a word in is the empty string
    for(int i = 0; i < rules; i++)
    {
        //if wordin is empty string
        if(strlen(wordin[i]) == 0)
        {
            //shift all wordin and wordout elements one spot forward
            shift(wordin, wordout, rules, i);
        }
    }
    
    //loop through each word and remove match rule if a word contains a character that is not a letter
    for(int i = 0; i < rules; i++)
    {
        //loop through each character in wordin
        for(int j = 0; j < strlen(wordin[i]); j++)
        {
            //if a character is not a letter
            if(!isalpha(wordin[i][j]))
            {
                //shift all wordin and wordout elements one spot forward
                shift(wordin, wordout, rules, i);
                break;
            }
        }
    }
    
    //loop through each word and remove match rule if a word contains a character that is not a letter
    for(int i = 0; i < rules; i++)
    {
        //loop through each character in wordout
        for(int k = 0; k < strlen(wordout[i]); k++)
        {
            //if a character is not a letter
            if(!isalpha(wordout[i][k]))
            {
                //shift all wordin and wordout elements one spot forward
                shift(wordin, wordout, rules, i);
                break;
            }
        }
    }

    //remove match rule if the wordin and the wordout are the same
    for(int i = 0; i < rules; i++)
    {
        if(strcmp(wordin[i], wordout[i]) == 0)
        {
            //shift all wordin and wordout elements one spot forward
            shift(wordin, wordout, rules, i);
        }
    }
    
    //loop through all elements in array
    for(int index = 0; index < rules; index++)
    {
        //if one word match rule
        if(strlen(wordout[index]) == 0)
        {
            //iterate through all elements in array a second time
            for(int j = 0; j < rules; j++)
            {
                //check that indices are different, if 2 identical wordins exist
                if((index != j) && strcmp(wordin[index], wordin[j]) == 0)
                {
                    //change wordout to empty string for 2 word match rule
                    strcpy(wordout[j], "");
                }
            }
        }
    }
    
    //loop through elements in array
    for(int index = 0; index < rules; index++)
    {
        //loop through again
        for(int j = index + 1; j < rules; j++)
        {
            //if 2 sets of match rules are identical
            if((strcmp(wordin[index], wordin[j]) == 0) && (strcmp(wordout[index], wordout[j]) == 0))
            {
                //shift all wordin and wordout elements one spot forward
                shift(wordin, wordout, rules, j);
            }
        }
    }
    //return number of match rules in correct forms
    return rules;
}

//determine score of document
int determineScore(const char document[],
                   const char wordin[][MAX_WORD_LENGTH+1],
                   const char wordout[][MAX_WORD_LENGTH+1],
                   int nRules)
{
    //define an integer to track score of document
    int score = 0;
    
    //treat negative nRules parameter as if it were 0
    if(nRules <= 0)
    {
        return 0;
    }
    
    //define const int that is max size of document
    const int MAX_DOC_SIZE = 250;
    
    //initialize new c string that is size of original plus 2 spaces and 0 byte
    char newArray[MAX_DOC_SIZE + 3];
    //set first position of newArray to be space
    newArray[0] = ' ';
    
    //copy original c string into new c string
    int temp = 1;
    for(int i = 0; i < strlen(document); i++)
    {
        //only copy if character is letter
        if(isalpha(document[i]))
        {
            //convert letters to lowercase
            newArray[temp] = tolower(document[i]);
            temp++;
        }
        
        //copy if character is space
        else if(document[i] == ' ')
        {
            newArray[temp] = document[i];
            temp++;
        }
    }
    
    //set second to last element in newArray to space
    newArray[temp] = ' ';
    //set last element in newArray to null byte
    newArray[temp + 1] = '\0';
    
    //loop through match rules
    for(int i = 0; i < nRules; i++)
    {
        //create temporary copies of wordin and wordout whose first positions are space
        char tempwordin[MAX_WORD_LENGTH + 3] = " ";
        char tempwordout[MAX_WORD_LENGTH + 3] = " ";
        
        //add each wordin to tempwordin followed by space
        strcat(tempwordin, wordin[i]);
        strcat(tempwordin, " ");
        
        //add each wordout to tempwordout followed by space
        strcat(tempwordout, wordout[i]);
        strcat(tempwordout, " ");
        
        //create nullpointers for wordin and wordout
        char* sp1 = nullptr;
        char* sp2 = nullptr;
        
        //test if tempwordin is nullpointer
        sp1 = strstr(newArray, tempwordin);
        //test if tempwordout is nullpointer
        sp2 = strstr(newArray, tempwordout);
        
        //if wordin found in document and wordout is not found
        if((strcmp(wordout[i], "") == 0 && (sp1 != nullptr)) || ((sp2 == nullptr) && (sp1 != nullptr)))
        {
            //increment score
            score++;
        }
    }
    
    //return the score of the document, the number of rules that the document matches
    return score;
}

int main()
{
//    const int TEST1_NRULES = 12;
//    char test1win[TEST1_NRULES][MAX_WORD_LENGTH+1] = {
//        "confusion", "FAMILY", "charm", "hearty", "house", "worn-out", "family", "charm", "ties", "", "charm", "FaMiLy",
//    };
//    char test1wout[TEST1_NRULES][MAX_WORD_LENGTH+1]  = {
//        "", "TIES", "confusion", "hearty", "intrigue", "younger", "first", "", "family", "frightened", "", "tIeS",
//    };
//
//    int temp1 = cleanupRules(test1win, test1wout, 12);
//
//    //cout << temp1 << endl;
//
//    const int TEST2_NRULES = 6;
//    char test2win[TEST2_NRULES][MAX_WORD_LENGTH+1] = {
//        "FAMILY", "!!!", "", "cat", "fox", "bat",
//    };
//    char test2wout[TEST2_NRULES][MAX_WORD_LENGTH+1]  = {
//        "ABC", "horse", "horse", "cat", "", "gnat",
//    };
//
//    int temp2 = cleanupRules(test2win, test2wout, 6);
//
//    //cout << temp2 << endl;
//
//    const int TEST1_NRULES1 = 3;
//    char test1win1[TEST1_NRULES1][MAX_WORD_LENGTH+1] = {
//        "family", "unhappy", "horse",
//    };
//
//    char test1wout1[TEST1_NRULES1][MAX_WORD_LENGTH+1] = {
//        "",       "horse",   "",
//    };
//
//    assert(determineScore("Happy families are all alike; every unhappy family is unhappy in its own way.",
//                test1win1, test1wout1, TEST1_NRULES1) == 2);
//    assert(determineScore("Happy horses are all alike; every unhappy horse is unhappy in its own way.",
//                test1win1, test1wout1, TEST1_NRULES1-1) == 0);
//    assert(determineScore("Happy horses are all alike; every unhappy horse is unhappy in its own way.",
//                test1win1, test1wout1, TEST1_NRULES1) == 1);
//    assert(determineScore("A horse!  A horse!  My kingdom for a horse!",
//                test1win1, test1wout1, TEST1_NRULES1) == 1);
//    assert(determineScore("horse:stable ratio is 10:1",
//                test1win1, test1wout1, TEST1_NRULES1) == 0);
//    assert(determineScore("**** 2020 ****",
//                test1win1, test1wout1, TEST1_NRULES1) == 0);

// Check cleanupRules
    char given1[12][MAX_WORD_LENGTH + 1] = { "confusion",  "FAMILY", "charm", "hearty", "house", "worn-out", "family", "charm", "ties", "", "charm", "FaMiLy" };
    char given2[12][MAX_WORD_LENGTH + 1] = { "", "TIES", "confusion", "hearty", "intrigue", "younger", "first", "", "family", "frightened", "", "tIeS" };
    assert(cleanupRules(given1, given2, -1) == 0);
    assert(cleanupRules(given1, given2, 12) == 6);

    char allRules1[8][MAX_WORD_LENGTH + 1] = { "plank", "cross", "horses", "plank", "teal", "remove", "ucla", "space" };
    char allRules2[8][MAX_WORD_LENGTH + 1] = { "demon", "", "disposable", "despicable", "different", "", "", "rational" };
    assert(cleanupRules(allRules1, allRules2, 8) == 8);

    char basic1[12][MAX_WORD_LENGTH + 1] = { "believe", "running", "pants", "TESTIng", "believe", "relieve", "running", "ants", "relieve", "rethink", "believe", "ants" };
    char basic2[12][MAX_WORD_LENGTH + 1] = { "yourself", "flamingo", "", "ruinIng", "Yourself", "", "fruit", "suit", "yourself", "the past", "yOURSELf", "" };
    assert(cleanupRules(basic1, basic2, 12) == 7);

    char oneWord1[10][MAX_WORD_LENGTH + 1] = { "test", "", "right", "%aT", "", "eAT", "VegEtableS", "eaT", "EAT", "right" };
    char oneWord2[10][MAX_WORD_LENGTH + 1] = { "", "", "", "", "", "", "", "", "", "" };
    assert(cleanupRules(oneWord1, oneWord2, 10) == 4);

    char twoWord1[10][MAX_WORD_LENGTH + 1] = { "toasty", "BreaD", "", "stop", "toast", "toAsTy", " ", "bread", "go", "remove" };
    char twoWord2[10][MAX_WORD_LENGTH + 1] = { "bread", "ToaSty", "continue", "stop", "bread", "bread", "top", "tOasTs", "stop", "bread" };
    assert(cleanupRules(twoWord1, twoWord2, 10) == 6);

    char noRules1[8][MAX_WORD_LENGTH + 1] = { "&plank", "cro$$", "demi-horse", "&plank", "tealblue", "remove it", "@ucla", "   " };
    char noRules2[8][MAX_WORD_LENGTH + 1] = { "demon", "", "disposable", "despicable", "(different)", "", "", "rational" };
    assert(cleanupRules(noRules1, noRules2, 8) == 0);

    char maxLengthRules1[6][MAX_WORD_LENGTH + 1] = { "INCOMPREHENSIBLENESS", "reversal", "indistinguishability", "", "distinguish-it", "denial" };
    char maxLengthRules2[6][MAX_WORD_LENGTH + 1] = { "", "nope", "mechanic", "operative", "stop", "INCOMPREHENSIBLENESS" };
    assert(cleanupRules(maxLengthRules1, maxLengthRules2, 6) == 4);


    // Check determineScore
//    char given1[6][MAX_WORD_LENGTH + 1] = { "confusion",  "family", "house", "family", "charm", "ties" };
//    char given2[6][MAX_WORD_LENGTH + 1] = { "", "ties", "intrigue", "first", "", "family" };
//    char givenDoc[] = "Happy families are all alike; every unhappy family is unhappy in its own way.";
//
//    char basic1[7][MAX_WORD_LENGTH + 1] = { "believe", "running", "pants", "testing", "relieve", "running", "ants" };
//    char basic2[7][MAX_WORD_LENGTH + 1] = { "yourself", "flamingo", "", "ruining", "", "fruit", "" };
//    char basicDoc[] = "You need to BELIEVE in YOURSELF!!! Relieve the tension, otherwise 200 ants will appear running towards you! ";
//
//    char oneWord1[4][MAX_WORD_LENGTH + 1] = { "test", "right", "eat", "vegetables" };
//    char oneWord2[4][MAX_WORD_LENGTH + 1] = { "", "", "", "" };
//    char oneWordDoc[] = "The right thing to do is eating your vegetables!";
//
//    char twoWord1[6][MAX_WORD_LENGTH + 1] = { "toasty", "bread", "toast", "bread", "go", "remove" };
//    char twoWord2[6][MAX_WORD_LENGTH + 1] = { "bread", "toasty",  "bread", "toasts", "stop", "bread" };
//    char twoWordDoc[] = "Toasty bread?! 20 pieces please, no wait... Go toast it for me! Wait 100 milliseconds before removing it! ! !";
//
//    char noCheck1[6][MAX_WORD_LENGTH + 1] = { "rip", "explain",  "new", "regional", "testing", "fleet" };
//    char noCheck2[6][MAX_WORD_LENGTH + 1] = { "", "removal",  "", "incident", "", "treatment" };
//    char noCheckDoc[] = "2020 4 //0\\ 8008 *[]* *^* *^* *()* 1001 \\0// 2020";
//
//    char allCheck1[8][MAX_WORD_LENGTH + 1] = { "plank", "cross", "horses", "plank", "teal", "remove", "ucla", "space" };
//    char allCheck2[8][MAX_WORD_LENGTH + 1] = { "sponge", "", "mane", "whale", "", "", " distinct ", "unknown" };
//    char allCheckDoc[] = "Teal ucla cross space remove plank horses";
//
//    char empty1[4][MAX_WORD_LENGTH + 1] = { "ridiculous",  "family", "house", "family " };
//    char empty2[4][MAX_WORD_LENGTH + 1] = { "confusion",  "family", "house", "family " };
//    char emptyDoc[] = "";
//
//    char break1[8][MAX_WORD_LENGTH + 1] = { "horses", "horse", "house", "rain", "hay", "money", "rats", "pay" };
//    char break2[8][MAX_WORD_LENGTH + 1] = { "play", "", "", "today", "bale", "pay", "platinum", "" };
//    char breakDoc[] = "Horse-play is meant for outside! Not in this birdhouse, we pay rent like people, not big rats";
//
//    char maxLength1[6][MAX_WORD_LENGTH + 1] = { "max", "rip", "characters", "beyond", "eye", "end" };
//    char maxLength2[6][MAX_WORD_LENGTH + 1] = { "", "expect", "geese", "infinity", "", "" };
//    char maxLengthDoc[] = "This is a max length document that goes beyond what you expect and decieves THE GENERAL EYE ! ! ! We can't stop you from believing that this will finally end before the l i m i t! But imagine * if * there were less than 250 characters??? *~shoCKIng~*";
//
//    char maxLengthRules1[4][MAX_WORD_LENGTH + 1] = { "INCOMPREHENSIBLENESS", "reversal", "indistinguishability", "denial" };
//    char maxLengthRules2[4][MAX_WORD_LENGTH + 1] = { "", "nope", "mechanic", "INCOMPREHENSIBLENESS" };
//    char maxLengthRulesDoc[] = "The reversal of this sentence reveals its inDISTINGUISHability from the rest, don't be in denial then!";
//
//    assert(determineScore(givenDoc, given1, given2, -2) == 0);
//    assert(determineScore(givenDoc, given1, given2, 6) == 2);
//    assert(determineScore(oneWordDoc, oneWord1, oneWord2, 4) == 2);
//    assert(determineScore(twoWordDoc, twoWord1, twoWord2, 6) == 2);
//    assert(determineScore(breakDoc, break1, break2, 8) == 2);
//    assert(determineScore(emptyDoc, empty1, empty1, 4) == 0);
//    assert(determineScore(noCheckDoc, noCheck1, noCheck2, 6) == 0);
//    assert(determineScore(allCheckDoc, allCheck1, allCheck2, 8) == 8);
//    assert(determineScore(maxLengthDoc, maxLength1, maxLength2, 6) == 5);
//    assert(determineScore(maxLengthRulesDoc, maxLengthRules1, maxLengthRules2, 4) == 3);
//
    cout << "All tests succeeded" << endl;
}
